import http.server
import socketserver
import os
fail = False
try:
    import requests
except ImportError:
    os.system('pip install requests')
    try:
        import requests
    except:
        fail = True
if fail:
    print("Ocorreu um erro ao intalar requests para streaming do video.")
    exit()
import threading
import subprocess

import re

PORT = 8080

remote_url = input("Digite a URL do video (.enc): ").strip()
key = input("Digite a chave: ").strip().encode()

class ProxyHandler(http.server.BaseHTTPRequestHandler):

    def do_GET(self):
        headers = {}

        if "Range" in self.headers:
            headers["Range"] = self.headers["Range"]

        try:
            with requests.get(remote_url, headers=headers, stream=True) as r:

                self.send_response(r.status_code)

                for h in ["Content-Type", "Content-Length", "Content-Range"]:
                    if h in r.headers:
                        self.send_header(h, r.headers[h])

                self.send_header("Accept-Ranges", "bytes")
                self.end_headers()

                offset = 0

                if "Range" in self.headers:
                    m = re.search(r"bytes=(\d+)-", self.headers["Range"])
                    if m:
                        offset = int(m.group(1))

                for chunk in r.iter_content(chunk_size=8192):
                    if not chunk:
                        continue

                    chunk = bytearray(chunk)

                    for i in range(len(chunk)):
                        chunk[i] ^= key[(offset + i) % len(key)]

                    offset += len(chunk)
                    self.wfile.write(chunk)

        except Exception as e:
            print("Erro na requisição:", e)


def find_vlc():
    possible_paths = [
        r"C:\Program Files\VideoLAN\VLC\vlc.exe",
        r"C:\Program Files (x86)\VideoLAN\VLC\vlc.exe"
    ]

    for path in possible_paths:
        if os.path.exists(path):
            return path
    return None


print(f"\nProxy rodando em http://localhost:{PORT}")
print("O servidor será encerrado quando o VLC fechar.\n")

httpd = socketserver.ThreadingTCPServer(("", PORT), ProxyHandler)

vlc_path = find_vlc()

if not vlc_path:
    print("VLC não encontrado.")
    exit()

vlc_process = subprocess.Popen([vlc_path, f"http://localhost:{PORT}"])


def monitor_vlc():
    vlc_process.wait()
    print("\nVLC foi fechado. Encerrando servidor...")
    httpd.shutdown()


threading.Thread(target=monitor_vlc, daemon=True).start()

try:
    httpd.serve_forever()

except KeyboardInterrupt:
    print("\nEncerrando servidor manualmente...")

finally:
    httpd.shutdown()
    httpd.server_close()
    print("Servidor encerrado com sucesso.")
