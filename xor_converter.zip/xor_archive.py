import os
import sys

# 🔑 pedir chave de criptografia
key_input = input("Digite a KEY de criptografia: ").strip()

if not key_input:
    print("KEY não pode ser vazia. Encerrando.")
    sys.exit(1)

KEY = key_input.encode()

CHUNK_SIZE = 1024 * 1024  # 1 MB

file_path = input("PATH DO VIDEO: ").strip()

if not os.path.isfile(file_path):
    print("Arquivo não encontrado.")
    sys.exit(1)

file_size = os.path.getsize(file_path)
processed = 0

# 📂 salvar na pasta onde o script está
script_dir = os.path.dirname(os.path.abspath(__file__))

base_name = os.path.basename(file_path)
output_file = os.path.join(script_dir, base_name + ".enc")

global_i = 0  # índice absoluto do arquivo

print("\nConvertendo...\n")

with open(file_path, 'rb') as fin, open(output_file, 'wb') as fout:
    while True:
        chunk = fin.read(CHUNK_SIZE)
        if not chunk:
            break

        out = bytearray(len(chunk))
        for i, b in enumerate(chunk):
            out[i] = b ^ KEY[(global_i + i) % len(KEY)]

        fout.write(out)

        processed += len(chunk)
        global_i += len(chunk)

        percent = processed * 100 / file_size
        bar_len = 40
        filled = int(bar_len * percent / 100)
        bar = '█' * filled + '-' * (bar_len - filled)

        print(f'\r[{bar}] {percent:6.2f}% ', end='', flush=True)

print(f'\n\nConcluído ✔')
print(f'Arquivo salvo em: {output_file}')
